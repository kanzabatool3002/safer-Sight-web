import React from "react";
import './rootStyle.css';
export default function Root() {
    return (
        <div className="main">
            <div>
                <h1>SAFER SIGHT</h1>
                <h2>The blend of Security and Artificial Intelligence</h2>
                <img src={require("../assets/fyp_logo.png")} alt="logo" />
                <div className="btns">
                    <a href="../Login">Login</a>
                    <a href="default.asp" target="_blank">Signup</a>
                </div>
            </div>
        </div>
    );
}




// #0d0b41
// #262452

// import React from "react";
// import './style.css';

// export default function Login() {
//     return (
//         <div>

//         </div>
//     );
// }