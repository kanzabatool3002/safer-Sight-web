import React, { useState, useEffect } from "react";
import "./headerStyle.css";
import { FaEye, FaBell, FaPhotoVideo, FaFileVideo, FaSearch, FaUserCircle } from "react-icons/fa";
import { FaBoxArchive } from "react-icons/fa6";
// import { NavLink } from 'react-router-dom';


export default function Header({ children }) {
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    const currentDay = days[currentTime.getDay()];
    const currentMonth = months[currentTime.getMonth()];
    const currentDate = currentTime.getDate();
    const currentYear = currentTime.getFullYear();

    let currentHour = currentTime.getHours();
    const ampm = currentHour >= 12 ? 'PM' : 'AM';
    currentHour = currentHour % 12;
    currentHour = currentHour ? currentHour : 12; // convert 0 to 12

    const currentMinute = currentTime.getMinutes();
    const currentSecond = currentTime.getSeconds();

    return (
        <div class="container">
            <div className="left">
                <div className="safer-sight">
                    <h2 style={{ margin: "0px" }}>Safer Sight</h2>
                    <img src={require("../assets/fyp_logo.png")} alt="logo" />
                </div>
                <div className="content">
                    <ul>
                        <li>
                            <div class="side-nav">
                                {/* <NavLink to="../Home">Home</NavLink> */}
                                <FaEye />
                                <a href="../Home">Watching</a>
                            </div>
                        </li>
                        <li>
                            <div class="side-nav">
                                <FaBell />
                                <a href="#news">Alerts</a>
                            </div>
                        </li>
                        <li>
                            <div class="side-nav">
                                {/* <NavLink to="../Archive">Archive</NavLink> */}
                                <FaBoxArchive />
                                <a href="../Archive">Archive</a>
                            </div></li>
                        <li>
                            <div class="side-nav">
                                <FaPhotoVideo />
                                <a href="#about">Video Wall</a></div>
                        </li>
                        <li>
                            <div class="side-nav">
                                <FaFileVideo />
                                <a href="#about">Files</a></div>
                        </li>
                        <li>
                            <div class="side-nav">
                                <FaSearch /><a href="#Search">Search</a></div>
                        </li>
                    </ul>

                </div>
                <div className="profile">
                    <div>
                        <h2>Kanza Batool</h2>
                        <FaUserCircle />

                        <div className="date-time">
                            <p>{currentDay} {currentHour}:{currentMinute < 10 ? '0' + currentMinute : currentMinute} {ampm}</p>
                            <p>{currentDay} {currentMonth} {currentDate} {currentYear}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="body">{children}</div>
        </div>

    );
}