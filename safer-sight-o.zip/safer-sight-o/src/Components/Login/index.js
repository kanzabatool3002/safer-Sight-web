
import React from "react";
import './loginStyle.css';
import { FaUser } from "react-icons/fa";
import { CiLock } from "react-icons/ci";

export default function Login() {
    return (
        <div className="main">
            <div className="safer-sight">
                <h1>SAFER SIGHT</h1>
                <h2>The blend of Security and Artificial Intelligence</h2>
                <img src={require("../assets/fyp_logo.png")} alt="logo" />
            </div>
            <div className="login">
                <div>
                    <div className="heading">
                        <h1>LOGIN</h1>
                    </div>
                    <div class="input-container">
                        <FaUser />
                        <input type="email" id="email" name="email" placeholder="Enter Your Email" />
                    </div>
                    <div class="input-container">
                        <CiLock />
                        <input type="password" name="password" placeholder="Enter your Password" />
                    </div>
                    <div className="forgot">
                        <span class="psw">Forgot <a href="#">password?</a></span>
                    </div>
                    <div className="login-btn">
                        <a href="../Home">Login</a>
                    </div>

                    <p>Don't have an account? <a id="signup" href="#">SignUp</a> </p>
                </div>
            </div>
        </div >
    );
}