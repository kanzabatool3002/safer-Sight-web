import { GoTriangleRight } from "react-icons/go";

const StreetList = ({ streets }) => {
    return (
        <>
            {/* <ul className="street-list">
                {streets.map((street, index) => (
                    <li key={index}>{street} <GoTriangleRight /></li>
                ))}
            </ul> */}
            <ul className="street-list">
                {streets.map((street, index) => (
                    <li key={index}>{street}</li>
                ))}
            </ul>

        </>
    );
};

export default StreetList;