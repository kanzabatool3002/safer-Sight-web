import React, { useState } from 'react';
import StreetList from "./StreetList";
import { FaMinus, FaPlus } from "react-icons/fa";

const Dropdown = ({ streets }) => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };
    const street_name = ['Street 1', 'Street 2', 'Street 3'];
    return (
        <>
            <div className="dropdown">
                {/* <button className="dropdown-toggle" onClick={toggleDropdown}>
                Streets{isOpen ? '-' : '+'}
                Street 1{isOpen ? <FaMinus />
                    : <FaPlus />}
            </button> */}
                <button className="dropdown-toggle" onClick={toggleDropdown}>
                    sdds
                    {isOpen ? <FaMinus />
                        : <FaPlus />}
                </button>
                {isOpen && <StreetList streets={streets} />}
            </div>
        </>
    );
};

export default Dropdown;