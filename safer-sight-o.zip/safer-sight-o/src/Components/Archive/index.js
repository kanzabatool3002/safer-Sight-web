
import React from "react";
// import './style.css';
import Header from "../Header";

export default function Archive() {
    return (
        <Header>
            <div className="demo">
                <h1>safcdsad</h1>
                <p>sakjcxndsldxmjdejwnmj</p>
            </div>
        </Header>
    );
}