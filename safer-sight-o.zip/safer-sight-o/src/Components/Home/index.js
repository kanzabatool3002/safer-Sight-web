import React, { useState, useEffect } from "react";
import "./homeStyle.css";
// import { FaEye, FaBell, FaPhotoVideo, FaFileVideo, FaSearch, FaUserCircle } from "react-icons/fa";
// import { FaBoxArchive } from "react-icons/fa6";
import Header from './../Header/index';

import { FaSearch } from "react-icons/fa";
import { GoTriangleDown } from "react-icons/go";
import Dropdown from "../Utilities/Dropdown";


export default function Home() {
    // const [currentTime, setCurrentTime] = useState(new Date());

    // useEffect(() => {
    //     const timer = setInterval(() => {
    //         setCurrentTime(new Date());
    //     }, 1000);

    //     return () => clearInterval(timer);
    // }, []);

    // const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    // const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    // const currentDay = days[currentTime.getDay()];
    // const currentMonth = months[currentTime.getMonth()];
    // const currentDate = currentTime.getDate();
    // const currentYear = currentTime.getFullYear();

    // let currentHour = currentTime.getHours();
    // const ampm = currentHour >= 12 ? 'PM' : 'AM';
    // currentHour = currentHour % 12;
    // currentHour = currentHour ? currentHour : 12; // convert 0 to 12

    // const currentMinute = currentTime.getMinutes();
    // const currentSecond = currentTime.getSeconds();
    const street1 = ['Left Road View', 'Right Road View'];
    const streets = [' Road View', ' Road View'];
    const street2 = [' Road View', ' Road View'];

    return (
        <Header>
            <div class="container">
                {/* <h1></h1> */}
                {/* <div className="left">
                <div className="safer-sight">
                    <h2 style={{ margin: "0px" }}>Safer Sight</h2>
                    <img src={require("../assets/fyp_logo.png")} alt="logo" />
                </div>
                <div className="content">
                    <ul>
                        <li>
                            <div class="side-nav">
                                <FaEye />
                                <a href="#home">Watching</a>
                            </div>
                        </li>
                        <li>
                            <div class="side-nav">
                                <FaBell />
                                <a href="#news">Alerts</a>
                            </div>
                        </li>
                        <li>
                            <div class="side-nav">
                                <FaBoxArchive />
                                <a href="#contact">Archive</a></div></li>
                        <li>
                            <div class="side-nav">
                                <FaPhotoVideo />
                                <a href="#about">Video Wall</a></div>
                        </li>
                        <li>
                            <div class="side-nav">
                                <FaFileVideo />
                                <a href="#about">Files</a></div>
                        </li>
                        <li>
                            <div class="side-nav">
                                <FaSearch /><a href="#Search">Search</a></div>
                        </li>
                    </ul>
                </div>
                <div className="profile">
                    <div>
                        <h2>Kanza Batool</h2>
                        <FaUserCircle />

                        <div className="date-time">
                            <p>{currentDay} {currentHour}:{currentMinute < 10 ? '0' + currentMinute : currentMinute} {ampm}</p>
                            <p>{currentDay} {currentMonth} {currentDate} {currentYear}</p>
                        </div>
                    </div>
                </div>
            </div> */}

                <div className="middle">
                    <div>
                        <h1>Watching</h1>
                        <div class="search-container">
                            <FaSearch />
                            <input type="Search" name="Search" placeholder="Search" />
                        </div>
                        <div className="dropdwn-watching">
                            <div className="list">
                                <GoTriangleDown />
                                <h3>List</h3>
                            </div>
                            <div className="all-cameras">
                                <GoTriangleDown />
                                <h3>All Cameras</h3>
                            </div>
                        </div>
                        <div className="drop-container">
                            <Dropdown streets={streets} />
                            <Dropdown streets={street1} />
                            <Dropdown streets={street2} />
                        </div>
                    </div>

                </div>
                <div className="right">
                    <h1>jassaxsh</h1>
                </div>

            </div>
        </Header>
    );
}