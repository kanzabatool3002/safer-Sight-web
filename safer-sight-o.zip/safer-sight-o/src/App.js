// import logo from './logo.svg';
// import './App.css';
import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
// import Home from './Components/Home';
import Root from './Components/Root';
import Login from './Components/Login';
import Home from './Components/Home';
import Archive from './Components/Archive';
// import Card from './Components/Features/Card.js';
// import 'C:/Users/SKY/Desktop/safer/safer-sight/src/App.css';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Root />} />
        <Route path="/login" element={<Login />} />
        <Route path="/home" element={<Home />} />
        <Route path="/Archive" element={<Archive />} />
        {/* <Route path="/user" element={<Card />} /> */}
        {/* <Route path="/" element={<Home />} /> */}
        {/* <Route path="/form" element={<Form />} /> */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
